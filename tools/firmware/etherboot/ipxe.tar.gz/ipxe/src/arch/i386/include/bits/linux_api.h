#ifndef _I386_LINUX_API_H
#define _I386_LINUX_API_H

#define __SYSCALL_mmap __NR_mmap2

#endif /* _I386_LINUX_API_H */
